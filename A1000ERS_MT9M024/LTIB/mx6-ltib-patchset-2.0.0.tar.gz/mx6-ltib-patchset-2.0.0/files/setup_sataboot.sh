#!/bin/sh

FLASHSETUP_ROOT="`pwd`/../"
FLASHSETUP_SATA=$FLASHSETUP_ROOT/sata
FLASHSETUP_COMMON=$FLASHSETUP_ROOT/common

error(){
echo
echo '********************************************************'
echo '*********************** ERROR **************************'
echo '********************************************************'
echo
exit 1
}

# Search for SATA device
BLOCKDEV=`find /sys/devices/platform/ahci.0 -name sd? | sed -e 's/.*sd/sd/'`
[ "x$BLOCKDEV" == "x" ] && error

if [ $# -eq 0 ]
then echo "=== This script will do the following:"
    echo "=== - Write U-Boot boot loader to SATA disk ($BLOCKDEV)"
    echo "=== - Write Linux kernel to SATA disk ($BLOCKDEV)"
    echo "=== - Write rootfs to SATA disk ($BLOCKDEV)"
    echo "==="
    echo "=== OK? Sleeping for 5 seconds..."
    sleep 5
fi

echo "=== Writing U-Boot to SATA"
dd if=$FLASHSETUP_SATA/u-boot.bin of=/dev/$BLOCKDEV || error

echo "=== Deleting old U-Boot environment"
dd if=/dev/zero of=/dev/$BLOCKDEV bs=8K seek=96 count=1 || error

echo "=== Writing Linux kernel to SATA"
# Offset: 1MiB
dd if=$FLASHSETUP_COMMON/uImage of=/dev/$BLOCKDEV bs=1M seek=1 || error

echo "=== Partitioning SATA"
fdisk /dev/$BLOCKDEV <<EOF
o
u
n
p
1
20480

w
EOF
if [ $? -ne 0 ]
then error
fi

RETRIES=5
sleep 1
while [ ! -b /dev/${BLOCKDEV}1 ]; do
    RETRIES=`expr $RETRIES - 1`
    if [ $RETRIES -eq 0 ]; then
	break
    fi
    sleep 1
done

echo "=== Creating ext4 on SATA"
mkfs.ext4 /dev/${BLOCKDEV}1 || error
mount /dev/${BLOCKDEV}1 /mnt/cdrom || error
ORIGPWD=`pwd`
cd /mnt/cdrom || error

echo "=== Unpacking ROOTFS to SATA"
tar -xvjf $FLASHSETUP_COMMON/rootfs.tar.bz2 || error
cd $ORIGPWD || error
umount /mnt/cdrom || error

echo "=== Sync"
sync
sync
sync

echo
echo "=== SATA disk setup successful!"
echo "=== SATA disk contains boot loader, kernel and rootfs."
echo
