#!/bin/sh

error() {
    cd $WD
    echo
    echo '************************************************************************'
    echo '************************************************************************'
    echo '******************************* ERROR **********************************'
    echo '************************************************************************'
    echo '************************************************************************'
    exit 1
}
message() {
    echo '************************************************************************'
    for i in `seq 1 $#`; do
	j="echo \${${i}}"
	eval $j
    done
    echo '************************************************************************'
}

# some checks for directories
[ $# -eq 1 ] || { message "Usage: $0 <ltib-dir>" && error; }
[ -d packages ] || { message "Please run 'install' in its directory" && error; }
[ -d files ] || { message "Please run 'install' in its directory" && error; }
[ -x $1/ltib -a -f $1/ltib ] || { message "Target seems not to be the LTIB install directory" && error; }

RELEASENAME=`pwd|sed -e 's/.*mx6-ltib-patchset-//g'`
WD=`pwd`
INSTALLDIR=$1

INSTALLED=0
message "Installing..."
cp -rpP files/* $INSTALLDIR || error
if [ -d ${INSTALLDIR}/pkgs ] ; then
    cp packages/* ${INSTALLDIR}/pkgs/ || error
    INSTALLED=1
fi
if [ -d /opt/freescale/pkgs/ ]; then
    cp packages/* /opt/freescale/pkgs/ || error
    INSTALLED=1
fi
[ ${INSTALLED} -eq 1 ] || error

message "Done. LTIB patch set for Bluetechnix i.MX6 products installed successfully." \
"" \
"Next steps:" \
"  cd $1" \
"  ./ltib --preconfig config/platform/imx/cmimx6dq.cf" \
"Have fun! - Your Bluetechnix Team"
cd $WD
