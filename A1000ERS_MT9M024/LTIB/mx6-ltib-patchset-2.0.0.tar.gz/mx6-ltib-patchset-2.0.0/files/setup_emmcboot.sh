#!/bin/sh

FLASHSETUP_ROOT="`pwd`/../"
FLASHSETUP_EMMC=$FLASHSETUP_ROOT/emmc
FLASHSETUP_COMMON=$FLASHSETUP_ROOT/common

error(){
echo
echo '********************************************************'
echo '*********************** ERROR **************************'
echo '********************************************************'
echo
exit 1
}

if [ $# -eq 0 ]
then echo "=== This script will do the following:"
    echo "=== - Write U-Boot boot loader to eMMC (mmcblk0)"
    echo "=== - Write Linux kernel to eMMC (mmcblk0)"
    echo "=== - Write rootfs to eMMC (mmcblk0p1)"
    echo "==="
    echo "=== OK? Sleeping for 5 seconds..."
    sleep 5
fi

echo "=== Writing U-Boot to eMMC"
dd if=$FLASHSETUP_EMMC/u-boot.bin of=/dev/mmcblk0 || error

echo "=== Deleting old U-Boot environment"
dd if=/dev/zero of=/dev/mmcblk0 bs=8K seek=96 count=1 || error

echo "=== Writing Linux kernel to eMMC"
# Offset: 1MiB
dd if=$FLASHSETUP_COMMON/uImage of=/dev/mmcblk0 bs=1M seek=1 || error

echo "=== Partitioning eMMC"
fdisk /dev/mmcblk0 <<EOF
o
u
n
p
1
20480

w
EOF
if [ $? -ne 0 ]
then error
fi

RETRIES=5
sleep 1
while [ ! -b /dev/mmcblk0p1 ]; do
    RETRIES=`expr $RETRIES - 1`
    if [ $RETRIES -eq 0 ]; then
	break
    fi
    sleep 1
done

echo "=== Creating ext4 on eMMC"
mkfs.ext4 /dev/mmcblk0p1 || error
mount /dev/mmcblk0p1 /mnt/cdrom || error
ORIGPWD=`pwd`
cd /mnt/cdrom || error

echo "=== Unpacking ROOTFS to eMMC"
tar -xvjf $FLASHSETUP_COMMON/rootfs.tar.bz2 || error
cd $ORIGPWD || error
umount /mnt/cdrom || error

echo "=== Sync"
sync
sync
sync

echo
echo "=== eMMC-boot setup successful!"
echo "=== eMMC contains boot loader, kernel and rootfs."
echo
