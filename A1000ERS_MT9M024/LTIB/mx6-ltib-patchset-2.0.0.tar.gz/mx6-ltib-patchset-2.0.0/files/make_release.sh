#!/bin/sh

###################### config #####################

# release name
RELEASENAME="2.0.0"
# directory for installing
RELEASEDIR="/tmp/mx6-linux-release"

###################### /config ####################

WD=~

error() {
    cd $WD
    echo
    echo '************************************************************************'
    echo '************************************************************************'
    echo '******************************* ERROR **********************************'
    echo '************************************************************************'
    echo '************************************************************************'
    exit 1
}
message() {
    echo '************************************************************************'
    start=2
    end=`expr 2 + $1 - 1`
    for i in `seq $start $end`
    do j="echo \$${i}"
	eval $j
    done
    echo '************************************************************************'
}


# some checks for directories
message 1 "Checking"
[ -d rootfs ] || error
[ -d rpm/BUILD/linux-3.0.35 ] || error
[ -d rpm/BUILD/u-boot-2009.08 ] || error
mkdir -p $RELEASEDIR
[ -d $RELEASEDIR ] || error
WD=`pwd`
rm -rf ${RELEASEDIR}/* || error
RELEASESUBDIR=${RELEASEDIR}/mx6-ltib-patchset-${RELEASENAME}
mkdir -p ${RELEASESUBDIR}
[ -d ${RELEASESUBDIR} ] || error

message 1 "Creating git tags"
cd rpm/BUILD/ || error
KERNELVER=`ls -1d linux-*`
UBOOTVER=`ls -1d u-boot-*`
cd $KERNELVER || error
KERNELCOMMIT=`git log|tail -n 5|head -n 1|cut -f 2 -d " "`
# create kernel git tag
git tag -d ${RELEASENAME}
git tag -s ${RELEASENAME} -m "Bluetechnix i.MX6 Linux BSP Release $RELEASENAME" || error
cd ../${UBOOTVER}/ || error
UBOOTCOMMIT=`git log|tail -n 5|head -n 1|cut -f 2 -d " "`
# create u-boot git tag
git tag -d ${RELEASENAME}
git tag -s ${RELEASENAME} -m "Bluetechnix i.MX6 Linux BSP Release $RELEASENAME" || error
cd $WD || error
# create ltib git tag
git tag -d ${RELEASENAME}
git tag -s ${RELEASENAME} -m "Bluetechnix i.MX6 Linux BSP Release $RELEASENAME"

# persistent
mkdir ${RELEASESUBDIR}/files || error
FILESDIR=${RELEASESUBDIR}/files
mkdir ${RELEASESUBDIR}/packages || error
PACKAGESDIR=${RELEASESUBDIR}/packages

# temporary
mkdir ${RELEASESUBDIR}/patches || error
PATCHESDIR=${RELEASESUBDIR}/patches # do not change
mkdir ${RELEASESUBDIR}/temp || error
TEMPDIR=${RELEASESUBDIR}/temp # do not change

message 1 "Copying configuration and scripts"
cd $WD || error
# We need the install script in the patchset installation package
install -m 0755 install_release.sh ${RELEASESUBDIR}/install || error

# Copy new/updated config + spec files
COPY_FILES="\
build_kernel.sh
build_uboot.sh
config/platform/imx/busybox.config
config/platform/imx/cmimx6dq.cf
config/platform/imx/main.lkc
config/platform/imx/packages.lkc
config/platform/imx/pkg_map
config/userspace/packages.lkc
config/userspace/pkg_map
config/userspace/sysconfig.lkc
dist/lfs-5.1/alsa-lib/alsa-lib.spec
dist/lfs-5.1/alsa-utils/alsa-utils.spec
dist/lfs-5.1/arm-ds5/gator-daemon.spec
dist/lfs-5.1/arm-ds5/gator-driver.spec
dist/lfs-5.1/cmimx6-support/cmimx6-support.spec
dist/lfs-5.1/fsl-mm/gst-fsl-plugins.spec
dist/lfs-5.1/gst-plugins-bad/gst-plugins-bad.spec
dist/lfs-5.1/gst-plugins-base/gst-plugins-base.spec
dist/lfs-5.1/gst-plugins-good/gst-plugins-good.spec
dist/lfs-5.1/gst-ffmpeg/gst-ffmpeg.spec
dist/lfs-5.1/libfftw/libfftw.spec
dist/lfs-5.1/libusb/libusb.spec
dist/lfs-5.1/mbw/mbw.spec
dist/lfs-5.1/memtester/memtester.spec
dist/lfs-5.1/minicom/minicom.spec
dist/lfs-5.1/mxc-misc/imx-test.spec
dist/lfs-5.1/mxc-misc/mmatools.spec
dist/lfs-5.1/ntpclient/ntpclient.spec
dist/lfs-5.1/samba/samba.spec
dist/lfs-5.1/sysconfig/sysconfig-mx.spec
dist/lfs-5.1/tslib/tslib.spec
dist/lfs-5.1/wpa_supplicant/wpa_supplicant.spec
install_deploy_images.sh
install_release.sh
make_release.sh
set-toolchain-path
setup_emmcboot.sh
setup_sataboot.sh
setup_sdcard.sh
setup_spiboot.sh"

for i in $COPY_FILES; do
    mkdir -p "${FILESDIR}/`dirname $i`" || error
    cp $i ${FILESDIR}/$i || error
done

# Copy new/updated packages
message 1 "Copying package archives"
COPY_PACKAGES="\
rpm/SOURCES/0001-gstffmpegdemux.c-Remove-deprecated-flow-macros.patch
rpm/SOURCES/alsa-lib-1.0.25.tar.bz2
rpm/SOURCES/alsa-utils-1.0.25.tar.bz2
rpm/SOURCES/cmimx6-support.tar.bz2
rpm/SOURCES/fftw-3.3.3.tar.gz
rpm/SOURCES/gator-daemon.tar.gz
rpm/SOURCES/gator-daemon-use-host-compiler-for-escape.patch
rpm/SOURCES/gator-driver.tar.gz
rpm/SOURCES/gst-fsl-plugins-support-bayer-and-gray-sensor.patch
rpm/SOURCES/gst-plugins-bad-0.10.11-update-bayer2rgb.patch
rpm/SOURCES/gst-plugins-bad-ismconv.patch
rpm/SOURCES/gst-plugins-base-videorate-bayer.patch
rpm/SOURCES/gst-plugins-good-0.10.30-fix-multifilesink.patch
rpm/SOURCES/imx-test-bluetechnix-ism-support.patch
rpm/SOURCES/mbw.tar.gz
rpm/SOURCES/memtester-4.1.3.tar.gz
rpm/SOURCES/memtester-makefile.patch
rpm/SOURCES/minicom_2.6.1.orig.tar.gz
rpm/SOURCES/mmatools-1.0.tar.bz2
rpm/SOURCES/ntpclient_2010_365.tar.gz
rpm/SOURCES/tslib-1.0.tar.bz2
rpm/SOURCES/wpa_supplicant-1.0.tar.gz"

for i in $COPY_PACKAGES; do 
    cp $i ${PACKAGESDIR}/ || error
done

message 1 "Creating Linux kernel patches"
LINUXPACKAGE=linux-3.0.35-imx_4.0.0.bz2

cd $WD || error
cd rpm/BUILD/${KERNELVER}/ || error
rm -rf ${PATCHESDIR}/* || error
git format-patch -s -o ${PATCHESDIR} ${KERNELCOMMIT} > /dev/null
echo "-blt-imx6-`git describe --always`" > ${PATCHESDIR}/localversion
rm -rf ${TEMPDIR}/* || error
cp /opt/freescale/pkgs/${LINUXPACKAGE} ${TEMPDIR} || error
cd ${TEMPDIR} || error
tar -xjf ${LINUXPACKAGE} || error
rm -f patches/*.patch || error
cp ${PATCHESDIR}/* patches/ || error
tar -cjf ${LINUXPACKAGE} patches || error
cp ${LINUXPACKAGE} ${PACKAGESDIR} || error

message 1 "Creating U-Boot patches"
UBOOTPACKAGE=u-boot-v2009.08-imx_3.0.35_4.0.0.tar.bz2

cd $WD || error
cd rpm/BUILD/${UBOOTVER}/ || error
rm -rf ${PATCHESDIR}/* || error
git format-patch -s -o ${PATCHESDIR} ${UBOOTCOMMIT} > /dev/null
echo "-blt-imx6-`git describe --always`" > ${PATCHESDIR}/localversion
rm -rf ${TEMPDIR}/* || error
cp /opt/freescale/pkgs/${UBOOTPACKAGE} ${TEMPDIR} || error
cd ${TEMPDIR} || error
tar -xjf ${UBOOTPACKAGE} || error
rm -f patches/*.patch || error
cp ${PATCHESDIR}/* patches/ || error
tar -cjf ${UBOOTPACKAGE} patches || error
cp ${UBOOTPACKAGE} ${PACKAGESDIR} || error

message 1 "Creating md5sums for packages"
cd ${PACKAGESDIR}
for i in `ls -1`
do md5sum $i > ${i}.md5 || error
done

message 1 "Compressing"
rm -rf ${TEMPDIR} ${PATCHESDIR} || error
cd ${RELEASEDIR}/ || error
tar -cjf mx6-ltib-patchset-${RELEASENAME}.tar.bz2 mx6-ltib-patchset-${RELEASENAME} || error

message 1 "Cleaning up"
rm -rf mx6-ltib-patchset-${RELEASENAME} install || error

message 1 "md5sum"
md5sum mx6-ltib-patchset-${RELEASENAME}.tar.bz2 > mx6-ltib-patchset-${RELEASENAME}.tar.bz2.md5 || error

message 2 "Done. Release was created." "File: ${RELEASEDIR}/mx6-ltib-patchset-${RELEASENAME}.tar.bz2"
cd $WD
