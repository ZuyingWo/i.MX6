#!/bin/sh

LOGFILE=deploy_error.log

PATH_BASE=flash-setup
PATH_COMMON=$PATH_BASE/common
PATH_EMMC=$PATH_BASE/emmc
PATH_SPI=$PATH_BASE/spi
PATH_SATA=$PATH_BASE/sata


error() {
    echo
    echo '********************************************************'
    echo '*********************** ERROR **************************'
    echo '********************************************************'
    echo
    echo "(See ${LOGFILE} for last messages.)"
    exit 1
}

echo
echo "=== This script will copy SPI/eMMC/SATA flash setup files"
echo "=== (U-Boot, Linux, ext4 rootfs) for Bluetechnix i.MX6"
echo "=== products to any location."
echo "=== "

echo
echo "=== USAGE: ${0} <path>"
echo "===   <path> ....... Path for setup images"
echo "=== "
echo

touch ${LOGFILE}

if [ $# -ne 1 ]
then
    echo "=== ERROR: First argument must be a valid path"
    echo "=== e.g. \"/home/bluetechnix/imx6_setup\""
    echo
    error
fi

MY_PATH="${1}"

# Path does not exist
if [ ! -d $MY_PATH ] 
then
    echo "${MY_PATH} is not a valid path!"
    error
fi 

FLASHSETUP_COMMON=$MY_PATH/$PATH_COMMON
FLASHSETUP_EMMC=$MY_PATH/$PATH_EMMC
FLASHSETUP_SPI=$MY_PATH/$PATH_SPI
FLASHSETUP_SATA=$MY_PATH/$PATH_SATA

# Detect i.MX6 Dual/Quad
QUAD=0
cat config/platform/imx/.config | grep "CONFIG_BOARD_CMIMX6Q=y" > /dev/null
if [ $? -eq 0 ]; then
    QUAD=1
fi

if [ $QUAD -eq 1 ]; then
    echo "=== Targeted module: CM-i.MX6 QUAD/DUAL"
else
    echo "=== Targeted module: CM-i.MX6 SOLO"
fi
echo


echo "=== Copying ROOTFS archive and kernel for flash setup"
mkdir -p $FLASHSETUP_COMMON || error
cd rootfs || error
TEMP_ROOTFS=`mktemp`
sudo tar -cjf $TEMP_ROOTFS ./* >../$LOGFILE 2>&1 || error 
cd .. || error
mv $TEMP_ROOTFS $FLASHSETUP_COMMON/rootfs.tar.bz2 || error
cp rootfs/boot/uImage $FLASHSETUP_COMMON || error
    
echo "=== Building U-Boot for eMMC"
./build_uboot.sh emmc >$LOGFILE 2>&1 || error
    
echo "=== Copying eMMC flash setup"
mkdir -p $FLASHSETUP_EMMC || error
cp rootfs/boot/u-boot.bin $FLASHSETUP_EMMC || error
cp setup_emmcboot.sh $FLASHSETUP_EMMC || error
chmod +x $FLASHSETUP_EMMC/setup_emmcboot.sh || error

echo "=== Building U-Boot for SPI flash"
./build_uboot.sh spiflash >$LOGFILE 2>&1 || error
    
echo "=== Copying SPI+eMMC flash setup"
mkdir -p $FLASHSETUP_SPI || error
cp rootfs/boot/u-boot.bin $FLASHSETUP_SPI || error
cp setup_spiboot.sh $FLASHSETUP_SPI || error
chmod +x $FLASHSETUP_SPI/setup_spiboot.sh || error

# Only i.MX6D/Q have SATA
if [ $QUAD -eq 1 ] ; then
    echo "=== Building U-Boot for SATA disk"
    ./build_uboot.sh sata >$LOGFILE 2>&1 || error
    
    echo "=== Copying SATA disk setup"
    mkdir -p $FLASHSETUP_SATA || error
    cp rootfs/boot/u-boot.bin $FLASHSETUP_SATA || error
    cp setup_sataboot.sh $FLASHSETUP_SATA || error
    chmod +x $FLASHSETUP_SATA/setup_sataboot.sh || error
fi

echo "=== Done!"
echo

echo "===   To setup eMMC flash, SPI flash, or SATA disk,"
echo "===   follow these instructions:"
echo "==="
echo "===   * For eMMC flash setup, run"
echo "===     $PATH_EMMC/setup_emmcboot.sh"
echo "===   * For SPI-NOR flash setup, run"
echo "===     $PATH_SPI/setup_spiboot.sh"
if [ $QUAD -eq 1 ] ; then
    echo "===   * For SATA disk setup, run"
    echo "===     $PATH_SATA/setup_sataboot.sh"
fi
echo
