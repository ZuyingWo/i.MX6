#!/bin/sh

LOGFILE=setup_sdcard.log
MOUNTPOINT=/media/sd_card
FLASHSETUP_ROOT=$MOUNTPOINT/opt/blt/flash-setup
FLASHSETUP_COMMON=$FLASHSETUP_ROOT/common
FLASHSETUP_EMMC=$FLASHSETUP_ROOT/emmc
FLASHSETUP_SPI=$FLASHSETUP_ROOT/spi
FLASHSETUP_SATA=$FLASHSETUP_ROOT/sata

error() {
    echo
    echo '********************************************************'
    echo '*********************** ERROR **************************'
    echo '********************************************************'
    echo
    echo "(See ${LOGFILE} for last messages.)"
    exit 1
}

echo
echo "=== This script will set up a bootable SD card for Bluetechnix i.MX6 products"
echo "=== including U-Boot, Linux, and ext4 rootfs."
echo
echo "=== USAGE: ${0} <blkdev> [-s <size_mb>] [-c]"
echo "===   <blkdev>.......SD card's block device file"
echo "===   -s <size_mb>...Size of ext4 rootfs partition on SD card"
echo "===   -c.............Copy SPI/eMMC flash setup files"
echo
echo

touch ${LOGFILE}

# Detect i.MX6 Dual/Quad
QUAD=0
cat config/platform/imx/.config | grep "CONFIG_BOARD_CMIMX6Q=y" > /dev/null
if [ $? -eq 0 ]; then
    QUAD=1
fi


# Parse arguments


if [ $# -lt 1 ]; then
    echo "=== ERROR: First argument must be the SD card's device file,"
    echo "=== e.g. /dev/sde or /dev/mmcblk0"
    echo
    error
fi
DEVICE_FILE=$1
PARTITION_SIZE=0
COPY_SETUP=0
if [ ! -b $1 ]; then
    echo "=== ERROR: First argument must be the SD card's device file,"
    echo "=== e.g. /dev/sde or /dev/mmcblk0"
    echo
    error
fi
shift 1
while [ $# -gt 0 ]; do
    if [ "$1" == "-s" ]; then
	if [ $# -lt 2 ]; then
	    echo "=== ERROR: Need partition size in MB if you specify '-s'"
	    echo
	    error
	else
	    PARTITION_SIZE=$2
	    shift 1
	fi
    fi
    if [ "$1" == "-c" ]; then
	COPY_SETUP=1
    fi
    shift 1
done
if [ "${DEVICE_FILE:0:11}" == "/dev/mmcblk" ]
then FIRSTPARTITION="${DEVICE_FILE}p1"
else
    FIRSTPARTITION="${DEVICE_FILE}1"
fi

if [ $QUAD -eq 1 ]; then
    echo "=== Targeted module: CM-i.MX6 QUAD/DUAL"
else
    echo "=== Targeted module: CM-i.MX6 SOLO"
fi
echo


# Setup SD card


if [ "`mount | grep \"${FIRSTPARTITION}\"`" != "" ]
then echo "=== ${FIRSTPARTITION} is mounted, unmounting it..."
    sudo umount ${FIRSTPARTITION} || error
fi
echo "=== Cleaning SD card"
sudo dd if=/dev/zero of=${DEVICE_FILE} bs=1M count=25 >$LOGFILE 2>&1 || error
echo "=== Building U-Boot for SD card"
./build_uboot.sh sd1 >$LOGFILE 2>&1 || error
echo "=== Writing U-Boot"
sudo dd if=rootfs/boot/u-boot.bin of=$DEVICE_FILE >$LOGFILE 2>&1 || error
sync
echo "=== Writing Linux kernel"
sudo dd if=rootfs/boot/uImage of=$DEVICE_FILE bs=1M seek=1 >$LOGFILE 2>&1 || error
sync
echo "=== Creating the partition ${FIRSTPARTITION}"
if [ $PARTITION_SIZE -eq 0 ]; then
    sudo fdisk ${DEVICE_FILE} >$LOGFILE 2>&1 <<EOF
n
p
1
+20M

w
EOF
else
    sudo fdisk ${DEVICE_FILE} >$LOGFILE 2>&1 <<EOF
n
p
1
+20M
+${PARTITION_SIZE}M
w
EOF
fi
if [ $? -ne 0 ]
then error
fi
sync
sleep 5 #wait for automounter
if [ "`mount | grep \"${FIRSTPARTITION}\"`" != "" ]
then echo "=== ${FIRSTPARTITION} is mounted, unmounting it..."
    sudo umount ${FIRSTPARTITION} || error
fi
echo "=== Making ext4 FS on ${FIRSTPARTITION}"
sudo mkfs.ext4 ${FIRSTPARTITION} >$LOGFILE 2>&1 || error
sync
grep -q ${FIRSTPARTITION} /proc/mounts >$LOGFILE 2>&1
if [ $? -eq 0 ]
then
    sudo umount ${FIRSTPARTITION} || error
fi
sudo mkdir -p $MOUNTPOINT  || error
sudo mount ${FIRSTPARTITION} $MOUNTPOINT  || error

echo "=== Copying rootfs data"
sudo cp -rpP rootfs/* $MOUNTPOINT || error

if [ $COPY_SETUP -eq 1 ]; then


    # Create rootfs archive and copy kernel


    echo "=== Copying ROOTFS archive and kernel for flash setup"

    sudo mkdir -p $FLASHSETUP_COMMON || error
    cd rootfs || error
    sudo tar -cvjf $FLASHSETUP_COMMON/rootfs.tar.bz2 ./* >../$LOGFILE 2>&1 || error
    cd .. || error
    sudo cp rootfs/boot/uImage $FLASHSETUP_COMMON || error


    # Create eMMC setup on SD card

    
    echo "=== Building U-Boot for eMMC"
    ./build_uboot.sh emmc >$LOGFILE 2>&1 || error
    
    echo "=== Copying eMMC flash setup"
    sudo mkdir -p $FLASHSETUP_EMMC || error
    sudo cp rootfs/boot/u-boot.bin $FLASHSETUP_EMMC || error
    sudo cp setup_emmcboot.sh $FLASHSETUP_EMMC || error
    sudo chmod +x $FLASHSETUP_EMMC/setup_emmcboot.sh || error


    # Create SPI flash setup on SD Card


    echo "=== Building U-Boot for SPI flash"
    ./build_uboot.sh spiflash >$LOGFILE 2>&1 || error
    
    echo "=== Copying SPI+eMMC flash setup"
    sudo mkdir -p $FLASHSETUP_SPI || error
    sudo cp rootfs/boot/u-boot.bin $FLASHSETUP_SPI || error
    sudo cp setup_spiboot.sh $FLASHSETUP_SPI || error
    sudo chmod +x $FLASHSETUP_SPI/setup_spiboot.sh || error


    # Create SATA flash setup on SD Card


    if [ $QUAD -eq 1 ] ; then
	echo "=== Building U-Boot for SATA disk"
	./build_uboot.sh sata >$LOGFILE 2>&1 || error
    
	echo "=== Copying SATA disk setup"
	sudo mkdir -p $FLASHSETUP_SATA || error
	sudo cp rootfs/boot/u-boot.bin $FLASHSETUP_SATA || error
	sudo cp setup_sataboot.sh $FLASHSETUP_SATA || error
	sudo chmod +x $FLASHSETUP_SATA/setup_sataboot.sh || error
    fi

fi

echo "=== Sync"
sync
sync
sync

echo "=== Unmount"
sudo umount `mount | grep "${FIRSTPARTITION}"| cut -f 3 -d " "` || error
sudo rmdir $MOUNTPOINT || error

echo "=== Done!"
echo
echo "=== The CM-i.MX6 is able to boot from this SD card."
echo

if [ $COPY_SETUP -eq 1 ]; then
    echo "===   To setup eMMC flash, SPI flash, or SATA disk,"
    echo "===   follow these instructions:"
    echo "==="
    echo "===   * Boot your CM-i.MX6 with this SD card"
    echo "===   * For eMMC flash setup, run"
    echo "===     $FLASHSETUP_EMMC/setup_emmcboot.sh"
    echo "===   * For SPI-NOR flash setup, run"
    echo "===     $FLASHSETUP_SPI/setup_spiboot.sh"
    if [ $QUAD -eq 1 ] ; then
        echo "===   * For SATA disk setup, run"
        echo "===     $FLASHSETUP_SATA/setup_sataboot.sh"
    fi
    echo
fi

echo
