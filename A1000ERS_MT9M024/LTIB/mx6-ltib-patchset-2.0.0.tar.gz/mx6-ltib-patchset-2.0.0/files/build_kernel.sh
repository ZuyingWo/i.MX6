#!/bin/bash
error(){
echo
echo '********************************************************'
echo '*********************** ERROR **************************'
echo '********************************************************'
echo
exit 1
}
#copy current config to place where ltib takes it
cp rpm/BUILD/linux/.config config/platform/imx/imx6_defconfig.dev || error
#delete old /lib/modules directories
sudo rm -rf rootfs/lib/modules/* || error
#build + deploy kernel and modules
./ltib -m scbuild -p kernel || error
./ltib -m scdeploy -p kernel || error
#regenerate modules.dep
./ltib -m scbuild -p modeps || error
./ltib -m scdeploy -p modeps || error
#copy uImage to /tftpboot for loading by target
cp rootfs/boot/uImage /tftpboot || error
echo '********** Linux kernel built successfully *********'
