#!/bin/bash
error() {
    if [ -e ${CONFIGFILE}_backup ]; then
	mv ${CONFIGFILE}_backup ${CONFIGFILE}
    fi
    echo
    echo '********************************************************'
    echo '*********************** ERROR **************************'
    echo '********************************************************'
    echo
    exit 1
}
UBOOTPATH=rpm/BUILD/u-boot-2009.08
QUAD=0
MFG=0
cat config/platform/imx/.config | grep "CONFIG_BOARD_CMIMX6Q=y"
if [ $? -eq 0 ]; then
    QUAD=1
fi
cat config/platform/imx/.config | grep "CONFIG_PKG_KERNEL_UPDATER=y"
if [ $? -eq 0 ]; then
    MFG=1
fi
if [ $QUAD == 1 ] ; then
    if [ $MFG == 1 ] ; then
	CONFIGFILE=${UBOOTPATH}/include/configs/cmimx6q_mfg.h
    else
	CONFIGFILE=${UBOOTPATH}/include/configs/cmimx6q.h
    fi
else
    if [ $MFG == 1 ] ; then
	CONFIGFILE=${UBOOTPATH}/include/configs/cmimx6s_mfg.h
    else
	CONFIGFILE=${UBOOTPATH}/include/configs/cmimx6s.h
    fi
fi

ENVSTORAGE=spiflash
if [ $# -eq 0 ]
then echo '********************************************************'
    echo 'You may want to specify where the environment will be'
    echo 'saved. Possible values:'
    echo $0 spiflash
    echo $0 emmc
    echo $0 sd1
    echo $0 sata
    echo
    echo 'Default is SPI flash. Continuing in 5 seconds...'
    echo '********************************************************'
    sleep 5
else
    ENVSTORAGE=$1
fi
[ -d $UBOOTPATH ] || { ./ltib -m prep -p u-boot || error; }
make -C $UBOOTPATH clean || error
case $ENVSTORAGE in
    spiflash)
	# SPI Flash is default for env, ok
	# Boot mode default is eMMC, ok
	;;
    emmc)
	cp ${CONFIGFILE} ${CONFIGFILE}_backup || error
	# Change env storage to eMMC
	sed -i -e "s/#define CONFIG_FSL_ENV_IN_SF/#define CONFIG_FSL_ENV_IN_MMC/g" ${CONFIGFILE} || error
	# Default MMC number is 1, ok
	# Boot mode default is eMMC, ok
	;;
    sd1)
	cp ${CONFIGFILE} ${CONFIGFILE}_backup || error
	# Change env storage to SD
	sed -i -e "s/#define CONFIG_FSL_ENV_IN_SF/#define CONFIG_FSL_ENV_IN_MMC/g" ${CONFIGFILE} || error
	# Change default MMC number to SD
	sed -i -e "s/#define CONFIG_SYS_MMC_ENV_DEV  1/#define CONFIG_SYS_MMC_ENV_DEV  0/g" ${CONFIGFILE} || error
	# Change boot mode to SD
	sed -i -e "s/bootcmd=run bootcmd_emmc/bootcmd=run bootcmd_sd/g" ${CONFIGFILE} || error
	;;
    sata)
	if [ $QUAD == 0 ] ; then
	    echo
	    echo "***Error: i.MX6DL does not support SATA!"
	    error
	fi
	cp ${CONFIGFILE} ${CONFIGFILE}_backup || error
	# Change env storage to SATA
	sed -i -e "s/#define CONFIG_FSL_ENV_IN_SF/#define CONFIG_FSL_ENV_IN_SATA/g" ${CONFIGFILE} || error
	# Change boot mode to SATA
	sed -i -e "s/bootcmd=run bootcmd_emmc/bootcmd=run bootcmd_sata/g" ${CONFIGFILE} || error
	;;
    *)
	echo
	echo Argument \"$1\" is invalid. Exiting.
	error
	;;
esac
./ltib -m scbuild -p u-boot || error
./ltib -m scdeploy -p u-boot || error
cp rootfs/boot/u-boot.bin /tftpboot || error
if [ -e ${CONFIGFILE}_backup ]
then mv ${CONFIGFILE}_backup ${CONFIGFILE} || error
fi
echo '********** U-boot built successfully *********'
